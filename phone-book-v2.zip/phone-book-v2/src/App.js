import "./App.css";
import PhoneMain from "./component/PhoneMain";

function App() {
  return (
    <div className="App">
      <PhoneMain />
    </div>
  );
}

export default App;
